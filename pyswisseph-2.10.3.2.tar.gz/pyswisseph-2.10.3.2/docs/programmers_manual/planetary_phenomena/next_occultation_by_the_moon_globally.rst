==================================================================
Find the next occultation of a planet or star by the moon globally
==================================================================

The same function can also be used for global solar eclipses instead of
``sol_eclipse_when_glob()``, but is a bit less efficient.

.. autofunction:: swisseph.lun_occult_when_glob

..
