=============================
Attributes of a lunar eclipse
=============================

.. autofunction:: swisseph.lun_eclipse_how

..
