===========================================================
Attributes of a solar eclipse for a given position and time
===========================================================

.. autofunction:: swisseph.sol_eclipse_how

..
