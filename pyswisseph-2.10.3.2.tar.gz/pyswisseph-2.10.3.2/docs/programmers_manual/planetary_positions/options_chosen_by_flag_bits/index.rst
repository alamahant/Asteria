===========================
Options chosen by flag bits
===========================

.. toctree::
    :maxdepth: 3

    the_use_of_flag_bits
    ephemeris_flags
    speed_flags
    coordinate_systems
    specialities

..
