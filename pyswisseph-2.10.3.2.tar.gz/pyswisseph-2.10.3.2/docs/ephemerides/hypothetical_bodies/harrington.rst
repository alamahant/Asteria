==========
Harrington
==========

This is another attempt to predict Planet X's orbit and position from
perturbations in the orbits of Uranus and Neptune. It was published in The
Astronomical Journal 96(4), October 1988, p. 1476ff. Its precision is meant to
be of the order of +/- 30 degrees. According to Harrington there is also the
possibility that it is actually located in the opposite constellation, i.e.
Taurus instead of Scorpio. The planet has a mean solar distance of about 100
AU and a period of about 1000 years.

..
