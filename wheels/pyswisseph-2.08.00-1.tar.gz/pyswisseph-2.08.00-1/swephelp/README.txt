===============
Swephelp README
===============

Swephelp is a helper library based on (and for) the Swiss Ephemeris library.
It is not part of the Swiss Ephemeris library itself.

It features a collection of functions frequently used in astrology applications.

Functions for dates and time, geographical information, indian astrology,
transits search, constant values for aspects, signs, planets...

Stanislas Marquis <stan@astrorigin.com>

..
