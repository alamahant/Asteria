======================
Asteroid 99942 Apophis
======================

99942 Apophis is a near-Earth asteroid which sometime in the future impact
Earth. The ephemeris of this object is particularly uncertain after 13 April
2029 when it will have a very close encounter with the earth. Our ephemeris was
created from data from JPL Horizons.

Horizons's ephemeris of Apophis after 2029 varies considerable depending on the
start date and step width one uses in the Horizons web interface. (If you don't
believe it, please try it out!) However, as pointed out by Jon Giorgini in a
Mail to Dieter Koch of 1 April 2020, this variation is smaller than the
uncertainty of the orbit.

We will have to update our ephemeris of Apophis after his close encounter with
Earth in April 2029 in order to make it accurate at least until the year 2036.

..
