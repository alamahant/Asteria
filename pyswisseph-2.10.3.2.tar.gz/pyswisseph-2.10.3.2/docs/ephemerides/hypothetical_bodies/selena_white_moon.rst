=================
Selena/White Moon
=================

This is a 'hypothetical' second Moon of the Earth (or a third one, after the
"Black Moon") of obscure provenance. Many Russian astrologers use it. Its
distance from the Earth is more than 20 times the distance of the Moon and it
moves about the Earth in 7 years. Its orbit is a perfect, unperturbed circle.
Of course, the physical existence of such a body is not possible. The gravities
of Sun, Earth, and Moon would strongly influence its orbit.

..
