========================================
Example of a typical eclipse calculation
========================================

Find the next total eclipse, calculate the geographical position where it is
maximal and the four contacts for that position (for a detailed explanation of
all eclipse functions see the next chapters):

.. literalinclude:: example.py
    :language: python

..
