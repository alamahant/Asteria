======
Vulcan
======

This is a 'hypothetical' planet inside the orbit of Mercury (not identical to
the "Uranian" planet Vulkanus). Orbital elements according to L.H. Weston. Note
that the speed of this "planet" does not agree with the Kepler laws. It is too
fast by 10 degrees per year.

..
