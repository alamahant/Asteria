====================================
Find the next lunar eclipse globally
====================================

.. autofunction:: swisseph.lun_eclipse_when

..
