======
Chiron
======

Positions of Chiron can be well computed for the time between 700 CE and 4650
CE. As a result of close encounters with Saturn in Sept. 720 CE and in 4606 CE
we cannot trace its orbit beyond this time range. Small uncertainties in
today's orbital elements have chaotic effects before the year 700.

Do not rely on earlier Chiron ephemerides supplying a Chiron for Cesar's,
Jesus', or Buddha's birth chart. They are meaningless.

..
