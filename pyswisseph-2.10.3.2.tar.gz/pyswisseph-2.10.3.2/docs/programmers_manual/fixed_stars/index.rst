=====================
Fixed stars functions
=====================

.. toctree::
    :maxdepth: 3

    different_functions
    fixed_stars_positions
    fixed_stars_magnitude

..
