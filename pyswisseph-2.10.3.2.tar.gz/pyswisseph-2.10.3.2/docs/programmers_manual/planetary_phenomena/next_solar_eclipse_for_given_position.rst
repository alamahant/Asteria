=========================================================
Find the next solar eclipse for given geographic position
=========================================================

.. autofunction:: swisseph.sol_eclipse_when_loc

..
