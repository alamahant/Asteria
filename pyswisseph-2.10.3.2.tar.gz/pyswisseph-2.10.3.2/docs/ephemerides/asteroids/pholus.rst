======
Pholus
======

Pholus is a minor planet with orbital characteristics that are similar to
Chiron's. It was discovered in 1992. Pholus' orbital elements are not yet as
well-established as Chiron's. Our ephemeris is reliable from 1500 CE through
now. Outside the 20th century it will probably have to be corrected by several
arc minutes during the coming years.

..
