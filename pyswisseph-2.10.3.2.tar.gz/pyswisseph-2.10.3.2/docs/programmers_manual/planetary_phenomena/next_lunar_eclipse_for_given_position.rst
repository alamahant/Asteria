================================================
Find the next lunar eclipse for a given position
================================================

.. autofunction:: swisseph.lun_eclipse_when_loc

..
