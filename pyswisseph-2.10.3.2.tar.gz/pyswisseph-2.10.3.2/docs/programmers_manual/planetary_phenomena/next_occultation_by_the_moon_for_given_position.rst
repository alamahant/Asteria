==============================================================================
Find the next occultation of a planet or star by the moon for a given location
==============================================================================

This function can also be used for local solar eclipses instead of
``sol_eclipse_when_loc()``, but is a bit less efficient.

.. autofunction:: swisseph.lun_occult_when_loc



..
