==================================
Other functions that may be useful
==================================

.. autofunction:: swisseph.set_lapse_rate

.. autofunction:: swisseph.split_deg

..
