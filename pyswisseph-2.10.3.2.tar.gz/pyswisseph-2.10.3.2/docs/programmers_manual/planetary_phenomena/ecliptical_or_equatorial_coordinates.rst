====================================
Ecliptical or equatorial coordinates
====================================

.. autofunction:: swisseph.azalt_rev

..
